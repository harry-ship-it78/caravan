# Caravan Card Game (React + Vite)

A playable browser game inspired by Caravan-style pile building with A/J/Q/K effects, drag-and-drop interaction, and an AI opponent.

## Features

- Standard 52-card deck, shuffled
- Player and AI each have 3 piles ("caravans")
- Start with 5 cards in hand; draw 1 after each play (until deck is empty)
- Drag cards from your hand onto piles
- Special cards:
  - A: counts as 1
  - J: removes the previously placed card in that pile (Jack remains, 0 points); cannot be played on empty piles
  - Q: reverses the order of the pile (toggle based on parity of Queens present)
  - K: doubles the value of the card beneath it (stacks with consecutive Kings)
- You can play J/Q/K onto opponent piles (only if that pile is not empty). AI can do the same onto your piles.
- Piles show sequence and current total, recalculated after each move
- Cards stack with a slight overlap so you can see the underlying symbol; pile boxes are compact vertically
- AI takes turns automatically (simple random valid move); can be toggled on/off
- Game ends when all 6 piles (both sides) are at least 21; highest total wins

## Directory Structure

```
caravan-card-game/
├─ index.html
├─ package.json
├─ vite.config.js
├─ README.md
└─ src/
   ├─ App.jsx
   ├─ main.jsx
   ├─ styles.css
   ├─ components/
   │  ├─ Hand.jsx
   │  ├─ Pile.jsx
   │  ├─ Rules.jsx
   │  └─ Scoreboard.jsx
   └─ game/
      ├─ cardUtils.js
      └─ rules.js
```

## Requirements

- Node.js 18+ (recommended)
- npm or pnpm or yarn

## Run Locally

1. Install dependencies:

   ```bash
   npm install
   ```

2. Start the dev server:

   ```bash
   npm run dev
   ```

   Open the printed URL (e.g. `http://localhost:5173`) in your browser.

3. Build for production (optional):

   ```bash
   npm run build
   npm run preview
   ```

## How to Play

- It's your turn first. Drag a card from your hand onto one of your three piles, or play J/Q/K onto an AI pile (if it has at least one card).
- After placing a card, you automatically draw 1 card if the deck still has cards.
- Special card effects:
  - J: immediately removes the previously placed card in that pile (cannot be played on an empty pile).
  - Q: reverses the order of that pile; number of Queens in the pile toggles the orientation.
  - K: doubles the immediate card beneath it in the current visible order; consecutive Kings stack (2x per King).
- The AI plays onto its own piles, and may also play picture cards onto your piles when advantageous.
- The game ends when all piles (both players) have a total of at least 21. The winner is whoever has the higher sum across their three piles (ties are possible).

## Notes

- Aces currently count as 1. You can extend to 1/11 with additional UI.
- Jacks remain in the pile as 0-point cards after removing the previous card.
- Queens act as persistent toggles: current orientation is derived from the number of Queens present on a pile (odd = reversed).
- Face cards can be played onto opponent piles only if that pile is not empty (so the effect meaningfully applies).